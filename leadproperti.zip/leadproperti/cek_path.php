<?php
/**
 * CEK PATH LENGKAP - TAUFIKMARIE.COM
 * Version: 3.0.0 - Cek semua file & folder, bisa save PDF
 */

// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set waktu
date_default_timezone_set('Asia/Jakarta');

// Fungsi untuk format bytes
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
}

// Fungsi untuk cek permission
function getPermission($file) {
    if (!file_exists($file)) return '-';
    return substr(sprintf('%o', fileperms($file)), -4);
}

// Fungsi untuk cek writable
function isWritable($file) {
    if (!file_exists($file)) return false;
    return is_writable($file);
}

// ========== AMBIL PARAMETER ==========
$action = $_GET['action'] ?? 'view';
$format = $_GET['format'] ?? 'html';

// ========== DATA SERVER ==========
$server_info = [
    'PHP Version' => phpversion(),
    'Server Software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'Server Name' => $_SERVER['SERVER_NAME'] ?? 'Unknown',
    'Document Root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
    'Script Path' => __FILE__,
    'Script Name' => $_SERVER['SCRIPT_NAME'] ?? 'Unknown',
    'Request Time' => date('Y-m-d H:i:s'),
    'Memory Limit' => ini_get('memory_limit'),
    'Max Execution Time' => ini_get('max_execution_time') . ' seconds',
    'Max Upload Size' => ini_get('upload_max_filesize'),
    'Display Errors' => ini_get('display_errors') ? 'On' : 'Off'
];

// ========== DISK SPACE ==========
$total_space = disk_total_space('/');
$free_space = disk_free_space('/');
$used_space = $total_space - $free_space;
$usage_percent = round(($used_space / $total_space) * 100, 2);

$disk_info = [
    'Total Space' => formatBytes($total_space),
    'Free Space' => formatBytes($free_space),
    'Used Space' => formatBytes($used_space),
    'Usage %' => $usage_percent . '%'
];

// ========== DEFINE PATH ==========
$root_path = dirname(__FILE__);
$admin_path = $root_path . '/admin';
$api_path = $admin_path . '/api';
$includes_path = $admin_path . '/includes';
$logs_path = $admin_path . '/logs';
$uploads_path = $admin_path . '/uploads';
$uploads_canvasing = $uploads_path . '/canvasing';
$uploads_bukti = $uploads_path . '/bukti_pembayaran';
$uploads_akad = $uploads_path . '/akad';
$uploads_profiles = $uploads_path . '/profiles';
$uploads_seo = $uploads_path . '/seo';
$assets_path = $root_path . '/assets';

// ========== SEMUA PATH YANG DICEK ==========
$paths_to_check = [
    'ROOT_PATH' => $root_path,
    'ADMIN_PATH' => $admin_path,
    'API_PATH' => $api_path,
    'INCLUDES_PATH' => $includes_path,
    'LOGS_PATH' => $logs_path,
    'UPLOADS_PATH' => $uploads_path,
    'UPLOADS_CANVASING' => $uploads_canvasing,
    'UPLOADS_BUKTI' => $uploads_bukti,
    'UPLOADS_AKAD' => $uploads_akad,
    'UPLOADS_PROFILES' => $uploads_profiles,
    'UPLOADS_SEO' => $uploads_seo,
    'ASSETS_PATH' => $assets_path
];

// ========== FILE-FILE PENTING YANG HARUS ADA ==========
$important_files = [
    // ROOT FILES
    'Index Root' => $root_path . '/index.php',
    'Cek Path' => $root_path . '/cek_path.php',
    'Cek Path Lengkap' => $root_path . '/cek_path_lengkap.php',
    'Robots.txt' => $root_path . '/robots.txt',
    '.htaccess' => $root_path . '/.htaccess',
    
    // ADMIN API FILES
    'Config' => $api_path . '/config.php',
    'API Master' => $api_path . '/api_master.php',
    'Leads API' => $api_path . '/leads.php',
    'Booking Process' => $api_path . '/booking_process.php',
    'Get Available Units' => $api_path . '/get_available_units.php',
    'Get Tracking Config' => $api_path . '/get_tracking_config.php',
    'Generate SEO AI' => $api_path . '/generate_seo_ai.php',
    'Generate Schema' => $api_path . '/generate_schema.php',
    'Save Developer SEO' => $api_path . '/save_developer_seo.php',
    'Upload SEO Image' => $api_path . '/upload_seo_image.php',
    'Validate' => $api_path . '/validate.php',
    'Update Marketing' => $api_path . '/update_marketing.php',
    
    // ADMIN INCLUDES
    'Header' => $includes_path . '/header.php',
    'Footer' => $includes_path . '/footer.php',
    'Sidebar' => $includes_path . '/sidebar.php',
    'Head SEO' => $includes_path . '/head_seo.php',
    
    // ADMIN PAGES
    'Admin Index' => $admin_path . '/index.php',
    'Login' => $admin_path . '/login.php',
    'Logout' => $admin_path . '/logout.php',
    'Users' => $admin_path . '/users.php',
    'Profile' => $admin_path . '/profile.php',
    'Settings' => $admin_path . '/settings.php',
    'Backup' => $admin_path . '/backup.php',
    'Locations' => $admin_path . '/locations.php',
    'Messages' => $admin_path . '/messages.php',
    'Emails' => $admin_path . '/emails.php',
    'Tracking Config' => $admin_path . '/tracking_config.php',
    'Tracking Analytics' => $admin_path . '/tracking_analytics.php',
    'Tracking Debug' => $admin_path . '/tracking_debug.php',
    
    // SEO PAGES
    'Select Developer SEO' => $admin_path . '/select_developer_seo.php',
    'Developer SEO' => $admin_path . '/developer_seo.php',
    'Developer Manager' => $admin_path . '/developer_manager.php',
    
    // MARKETING PAGES
    'Marketing Dashboard' => $admin_path . '/marketing_dashboard.php',
    'Marketing Leads' => $admin_path . '/marketing_leads.php',
    'Marketing Booking' => $admin_path . '/marketing_booking.php',
    'External Booking' => $admin_path . '/external_booking.php',
    'Marketing Offline Form' => $admin_path . '/marketing_offline_form.php',
    'Marketing Canvasing' => $admin_path . '/marketing_canvasing.php',
    'Marketing Canvasing History' => $admin_path . '/marketing_canvasing_history.php',
    'Marketing Activities' => $admin_path . '/marketing_activities.php',
    'Marketing KPI' => $admin_path . '/marketing_kpi.php',
    'Marketing Leaderboard' => $admin_path . '/marketing_leaderboard.php',
    'Marketing Rekening' => $admin_path . '/marketing_rekening.php',
    
    // DEVELOPER PAGES
    'Developer Dashboard' => $admin_path . '/developer_dashboard.php',
    'Developer Clusters' => $admin_path . '/developer_clusters.php',
    'Developer Blocks' => $admin_path . '/developer_blocks.php',
    'Developer Units' => $admin_path . '/developer_units.php',
    'Developer Program Booking' => $admin_path . '/developer_program_booking.php',
    'Developer Biaya Kategori' => $admin_path . '/developer_biaya_kategori.php',
    'Developer Block Biaya' => $admin_path . '/developer_block_biaya.php',
    'Developer Banks' => $admin_path . '/developer_banks.php',
    'Developer Canvasing Dashboard' => $admin_path . '/developer_canvasing_dashboard.php',
    'Developer Tracking' => $admin_path . '/developer_tracking.php',
    'Developer Team' => $admin_path . '/developer_team.php',
    'Unit Programs' => $admin_path . '/unit_programs.php',
    
    // MANAGER DEVELOPER PAGES
    'Manager Developer Dashboard' => $admin_path . '/manager_developer_dashboard.php',
    'Manager Developer Komisi' => $admin_path . '/manager_developer_komisi.php',
    'Manager Developer Booking' => $admin_path . '/manager_developer_booking.php',
    'Manager Developer Canvasing' => $admin_path . '/manager_developer_canvasing.php',
    
    // FINANCE DEVELOPER PAGES
    'Finance Dashboard' => $admin_path . '/finance_dashboard.php',
    'Finance Komisi' => $admin_path . '/finance_komisi.php',
    'Finance Rekening' => $admin_path . '/finance_rekening.php',
    'Finance Laporan' => $admin_path . '/finance_laporan.php',
    'Finance Units Sold' => $admin_path . '/finance_units_sold.php',
    
    // FINANCE PLATFORM PAGES
    'Finance Platform Dashboard' => $admin_path . '/finance_platform_dashboard.php',
    'Finance Platform Verifikasi' => $admin_path . '/finance_platform_verifikasi.php',
    'Finance Platform Komisi' => $admin_path . '/finance_platform_komisi.php',
    'Finance Platform Rekening' => $admin_path . '/finance_platform_rekening.php',
    'Finance Platform Laporan' => $admin_path . '/finance_platform_laporan.php',
    'Finance Platform External' => $admin_path . '/finance_platform_external.php',
    
    // MANAGER PLATFORM PAGES
    'Manager Dashboard' => $admin_path . '/manager_dashboard.php',
    'Manager KPI' => $admin_path . '/manager_kpi.php',
    'Manager Top Performer' => $admin_path . '/manager_top_performer.php',
    'Manager Analisis' => $admin_path . '/manager_analisis.php',
    'Manager Activities' => $admin_path . '/manager_activities.php',
    'Manager Canvasing Dashboard' => $admin_path . '/manager_canvasing_dashboard.php'
];

// ========== DEVELOPER FOLDER ==========
$developer_folders = [
    'Kertamulya' => $root_path . '/kertamulya',
    'Kertayasa' => $root_path . '/kertayasa',
    'Ciperna' => $root_path . '/ciperna',
    'Windusari' => $root_path . '/windusari'
];

$developer_files = [
    'Kertamulya Index' => $root_path . '/kertamulya/index.php',
    'Kertayasa Index' => $root_path . '/kertayasa/index.php',
    'Ciperna Index' => $root_path . '/ciperna/index.php',
    'Windusari Index' => $root_path . '/windusari/index.php'
];

// ========== HITUNG STATISTIK ==========
$total_files_checked = count($important_files);
$files_exist = 0;
$files_missing = [];

foreach ($important_files as $name => $path) {
    if (file_exists($path)) {
        $files_exist++;
    } else {
        $files_missing[$name] = $path;
    }
}

// ========== FUNGSI RENDER HTML ==========
function renderHTML() {
    global $server_info, $disk_info, $paths_to_check, $important_files, $developer_folders, $developer_files;
    global $files_exist, $total_files_checked, $files_missing;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔍 Cek Path & Folder Lengkap - leadproperti.com</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f7fa;
            color: #1a2a24;
            line-height: 1.6;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .header {
            background: linear-gradient(135deg, #1B4A3C, #2A5F4E);
            color: white;
            padding: 25px 30px;
            border-radius: 16px 16px 0 0;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            font-size: 28px;
            font-weight: 700;
        }
        .header h1 i {
            margin-right: 10px;
            color: #E3B584;
        }
        .btn-group {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: #D64F3C;
            color: white;
        }
        .btn-primary:hover {
            background: #FF6B4A;
            transform: translateY(-2px);
            box-shadow: 0 8px 15px rgba(214,79,60,0.3);
        }
        .btn-secondary {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid rgba(255,255,255,0.3);
        }
        .btn-secondary:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            overflow: hidden;
            border: 1px solid #E0DAD3;
        }
        .card-header {
            background: linear-gradient(135deg, #E7F3EF, #d4e8e0);
            padding: 15px 20px;
            font-weight: 700;
            font-size: 18px;
            color: #1B4A3C;
            border-bottom: 2px solid #D64F3C;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .card-header i {
            color: #D64F3C;
        }
        .card-body {
            padding: 20px;
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        th {
            background: #f0f7f4;
            padding: 12px;
            text-align: left;
            font-weight: 700;
            color: #1B4A3C;
            border-bottom: 2px solid #D64F3C;
        }
        td {
            padding: 10px 12px;
            border-bottom: 1px solid #E0DAD3;
        }
        tr:hover td {
            background: #f9fbfa;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-ok {
            background: #d4edda;
            color: #155724;
            border-left: 3px solid #28a745;
        }
        .status-missing {
            background: #f8d7da;
            color: #721c24;
            border-left: 3px solid #dc3545;
        }
        .status-folder {
            background: #e7f3ef;
            color: #1B4A3C;
            border-left: 3px solid #1B4A3C;
        }
        .permission {
            font-family: monospace;
            font-size: 13px;
        }
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .summary-item {
            background: white;
            border-radius: 12px;
            padding: 20px;
            border-left: 6px solid #D64F3C;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
        .summary-value {
            font-size: 32px;
            font-weight: 800;
            color: #1B4A3C;
            line-height: 1.2;
        }
        .summary-label {
            font-size: 14px;
            color: #7A8A84;
            text-transform: uppercase;
        }
        .footer {
            text-align: center;
            padding: 20px;
            color: #7A8A84;
            font-size: 12px;
            border-top: 1px solid #E0DAD3;
            margin-top: 30px;
        }
        .missing-list {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .missing-list h3 {
            color: #856404;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .missing-list ul {
            list-style: none;
            padding-left: 20px;
        }
        .missing-list li {
            margin-bottom: 5px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-folder-tree"></i> Cek Path & Folder Lengkap</h1>
            <div class="btn-group">
                <a href="?format=html" class="btn btn-primary">
                    <i class="fas fa-sync-alt"></i> Refresh
                </a>
                <a href="?format=pdf&action=download" class="btn btn-secondary">
                    <i class="fas fa-download"></i> Download PDF
                </a>
                <a href="?format=html&action=print" onclick="window.print(); return false;" class="btn btn-secondary">
                    <i class="fas fa-print"></i> Print
                </a>
            </div>
        </div>
        
        <!-- SERVER INFO -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-server"></i> Informasi Server
            </div>
            <div class="card-body">
                <table>
                    <?php foreach ($server_info as $key => $value): ?>
                    <tr>
                        <td style="width: 200px; font-weight: 600;"><?= $key ?></td>
                        <td><?= htmlspecialchars($value) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
        
        <!-- DISK SPACE -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-hdd"></i> Disk Space
            </div>
            <div class="card-body">
                <table>
                    <?php foreach ($disk_info as $key => $value): ?>
                    <tr>
                        <td style="width: 200px; font-weight: 600;"><?= $key ?></td>
                        <td><?= $value ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
        
        <!-- SUMMARY -->
        <div class="summary">
            <div class="summary-item">
                <div class="summary-value"><?= $total_files_checked ?></div>
                <div class="summary-label">Total File Dicek</div>
            </div>
            <div class="summary-item">
                <div class="summary-value" style="color: #28a745;"><?= $files_exist ?></div>
                <div class="summary-label">File Ada</div>
            </div>
            <div class="summary-item">
                <div class="summary-value" style="color: #dc3545;"><?= count($files_missing) ?></div>
                <div class="summary-label">File Hilang</div>
            </div>
            <div class="summary-item">
                <div class="summary-value"><?= count($developer_folders) ?></div>
                <div class="summary-label">Developer Folder</div>
            </div>
        </div>
        
        <!-- MISSING FILES -->
        <?php if (!empty($files_missing)): ?>
        <div class="missing-list">
            <h3><i class="fas fa-exclamation-triangle"></i> File yang Hilang (<?= count($files_missing) ?>)</h3>
            <ul>
                <?php foreach ($files_missing as $name => $path): ?>
                <li><strong><?= $name ?>:</strong> <?= $path ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        
        <!-- SEMUA PATH -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-folder"></i> Semua Path yang Didefinisikan
            </div>
            <div class="card-body">
                <table>
                    <thead>
                        <tr>
                            <th>Nama Path</th>
                            <th>Path</th>
                            <th>Status</th>
                            <th>Permission</th>
                            <th>Writable</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($paths_to_check as $name => $path): 
                            $exists = file_exists($path);
                            $permission = getPermission($path);
                            $writable = isWritable($path);
                        ?>
                        <tr>
                            <td><strong><?= $name ?></strong></td>
                            <td><code><?= $path ?></code></td>
                            <td>
                                <?php if ($exists): ?>
                                <span class="status-badge status-ok">✅ Ada</span>
                                <?php else: ?>
                                <span class="status-badge status-missing">❌ Tidak Ada</span>
                                <?php endif; ?>
                            </td>
                            <td class="permission"><?= $permission ?></td>
                            <td><?= $writable ? '✅ Ya' : '❌ Tidak' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- FILE PENTING -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-file-code"></i> File Penting (<?= $files_exist ?>/<?= $total_files_checked ?>)
            </div>
            <div class="card-body">
                <table>
                    <thead>
                        <tr>
                            <th>Nama File</th>
                            <th>Lokasi</th>
                            <th>Status</th>
                            <th>Ukuran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $grouped_files = [];
                        foreach ($important_files as $name => $path) {
                            $category = explode(' ', $name)[0];
                            if (!isset($grouped_files[$category])) {
                                $grouped_files[$category] = [];
                            }
                            $grouped_files[$category][$name] = $path;
                        }
                        
                        foreach ($grouped_files as $category => $files): 
                        ?>
                        <tr style="background: #f0f7f4; font-weight: 700;">
                            <td colspan="4" style="padding: 8px 12px;">📁 <?= $category ?></td>
                        </tr>
                        <?php foreach ($files as $name => $path): 
                            $exists = file_exists($path);
                            $size = $exists ? formatBytes(filesize($path)) : '-';
                        ?>
                        <tr>
                            <td><?= $name ?></td>
                            <td><code><?= str_replace($root_path, '', $path) ?></code></td>
                            <td>
                                <?php if ($exists): ?>
                                <span class="status-badge status-ok">✅ Ada</span>
                                <?php else: ?>
                                <span class="status-badge status-missing">❌ Hilang</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $size ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- DEVELOPER FOLDER -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-building"></i> Developer Folder & File
            </div>
            <div class="card-body">
                <h3 style="margin-bottom: 15px;">📁 Folder Developer</h3>
                <table style="margin-bottom: 30px;">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Path</th>
                            <th>Status</th>
                            <th>Permission</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($developer_folders as $name => $path): 
                            $exists = file_exists($path);
                            $permission = getPermission($path);
                        ?>
                        <tr>
                            <td><strong><?= $name ?></strong></td>
                            <td><code><?= $path ?></code></td>
                            <td>
                                <?php if ($exists): ?>
                                <span class="status-badge status-folder">📁 Ada</span>
                                <?php else: ?>
                                <span class="status-badge status-missing">❌ Tidak Ada</span>
                                <?php endif; ?>
                            </td>
                            <td class="permission"><?= $permission ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <h3 style="margin-bottom: 15px;">📄 File Index Developer</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Nama File</th>
                            <th>Lokasi</th>
                            <th>Status</th>
                            <th>Ukuran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($developer_files as $name => $path): 
                            $exists = file_exists($path);
                            $size = $exists ? formatBytes(filesize($path)) : '-';
                        ?>
                        <tr>
                            <td><?= $name ?></td>
                            <td><code><?= str_replace($root_path, '', $path) ?></code></td>
                            <td>
                                <?php if ($exists): ?>
                                <span class="status-badge status-ok">✅ Ada</span>
                                <?php else: ?>
                                <span class="status-badge status-missing">❌ Hilang</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $size ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- ISI FOLDER LOGS -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-history"></i> Isi Folder Logs
            </div>
            <div class="card-body">
                <?php
                $log_files = [];
                if (is_dir($logs_path)) {
                    $log_files = scandir($logs_path);
                    $log_files = array_diff($log_files, ['.', '..']);
                }
                ?>
                <p><strong>Lokasi:</strong> <code><?= $logs_path ?></code></p>
                <p><strong>Total File:</strong> <?= count($log_files) ?></p>
                <?php if (!empty($log_files)): ?>
                <table style="margin-top: 15px;">
                    <thead>
                        <tr>
                            <th>Nama File</th>
                            <th>Ukuran</th>
                            <th>Terakhir Diubah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($log_files as $file): 
                            $file_path = $logs_path . '/' . $file;
                            $size = formatBytes(filesize($file_path));
                            $modified = date('d/m/Y H:i', filemtime($file_path));
                        ?>
                        <tr>
                            <td><code><?= $file ?></code></td>
                            <td><?= $size ?></td>
                            <td><?= $modified ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <p style="color: #7A8A84;">Folder logs kosong</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- ISI FOLDER UPLOADS -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-cloud-upload-alt"></i> Isi Folder Uploads
            </div>
            <div class="card-body">
                <?php
                $upload_subdirs = [
                    'akad' => $uploads_akad,
                    'bukti_pembayaran' => $uploads_bukti,
                    'canvasing' => $uploads_canvasing,
                    'profiles' => $uploads_profiles,
                    'seo' => $uploads_seo
                ];
                ?>
                <table>
                    <thead>
                        <tr>
                            <th>Subfolder</th>
                            <th>Path</th>
                            <th>Status</th>
                            <th>Jumlah File</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($upload_subdirs as $name => $path): 
                            $exists = file_exists($path);
                            $file_count = 0;
                            if ($exists) {
                                $files = scandir($path);
                                $file_count = count(array_diff($files, ['.', '..']));
                            }
                        ?>
                        <tr>
                            <td><strong><?= $name ?></strong></td>
                            <td><code><?= $path ?></code></td>
                            <td>
                                <?php if ($exists): ?>
                                <span class="status-badge status-ok">✅ Ada</span>
                                <?php else: ?>
                                <span class="status-badge status-missing">❌ Tidak Ada</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $file_count ?> file</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- KONEKSI DATABASE -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-database"></i> Cek Koneksi Database
            </div>
            <div class="card-body">
                <?php
                require_once 'admin/api/config.php';
                $conn = getDB();
                if ($conn) {
                    echo '<p style="color: #28a745; font-weight: 700;"><i class="fas fa-check-circle"></i> Koneksi database berhasil!</p>';
                    
                    // Cek tabel
                    $tables = $conn->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
                    echo '<p><strong>Total Tabel:</strong> ' . count($tables) . '</p>';
                    
                    // Cek data leads
                    $leads_count = $conn->query("SELECT COUNT(*) FROM leads")->fetchColumn();
                    echo '<p><strong>Total Leads:</strong> ' . number_format($leads_count) . '</p>';
                    
                    // Cek developer
                    $dev_count = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'developer'")->fetchColumn();
                    echo '<p><strong>Total Developer:</strong> ' . $dev_count . '</p>';
                    
                } else {
                    echo '<p style="color: #dc3545; font-weight: 700;"><i class="fas fa-exclamation-circle"></i> Koneksi database gagal!</p>';
                }
                ?>
            </div>
        </div>
        
        <!-- FOOTER -->
        <div class="footer">
            <p>© <?= date('Y') ?> leadproperti.com - Debug Path Checker v3.0</p>
            <p>Generated: <?= date('Y-m-d H:i:s') ?></p>
        </div>
    </div>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</body>
</html>
<?php
}

// ========== FUNGSI GENERATE PDF ==========
function generatePDF() {
    global $server_info, $disk_info, $paths_to_check, $important_files, $developer_folders, $developer_files;
    global $files_exist, $total_files_checked, $files_missing, $root_path, $logs_path;
    
    // Set header untuk download
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="cek_path_lengkap_' . date('Y-m-d') . '.html"');
    
    // Render HTML yang sama tapi dengan style print
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>🔍 Cek Path Lengkap - leadproperti.com</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: Arial, sans-serif; 
            background: white; 
            color: #000; 
            line-height: 1.5; 
            padding: 20px;
            font-size: 12px;
        }
        h1 { font-size: 24px; margin-bottom: 20px; color: #1B4A3C; }
        h2 { font-size: 18px; margin: 20px 0 10px; color: #1B4A3C; border-bottom: 2px solid #D64F3C; padding-bottom: 5px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 11px; }
        th { background: #E7F3EF; padding: 8px; text-align: left; border: 1px solid #ccc; font-weight: 700; }
        td { padding: 6px 8px; border: 1px solid #ccc; }
        .ok { color: green; font-weight: bold; }
        .missing { color: red; font-weight: bold; }
        .summary { margin: 20px 0; padding: 15px; background: #f5f5f5; border-left: 5px solid #D64F3C; }
        .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; border-top: 1px solid #ccc; padding-top: 10px; }
        code { background: #f0f0f0; padding: 2px 4px; border-radius: 3px; font-family: monospace; }
    </style>
</head>
<body>
    <h1>🔍 Cek Path & Folder Lengkap - leadproperti.com</h1>
    <p>Generated: <?= date('Y-m-d H:i:s') ?></p>
    
    <div class="summary">
        <p><strong>Total File Dicek:</strong> <?= $total_files_checked ?></p>
        <p><strong>File Ada:</strong> <?= $files_exist ?></p>
        <p><strong>File Hilang:</strong> <?= count($files_missing) ?></p>
        <p><strong>Developer Folder:</strong> <?= count($developer_folders) ?></p>
    </div>
    
    <h2>Informasi Server</h2>
    <table>
        <?php foreach ($server_info as $key => $value): ?>
        <tr><td style="width: 200px;"><strong><?= $key ?></strong></td><td><?= $value ?></td></tr>
        <?php endforeach; ?>
    </table>
    
    <h2>Disk Space</h2>
    <table>
        <?php foreach ($disk_info as $key => $value): ?>
        <tr><td style="width: 200px;"><strong><?= $key ?></strong></td><td><?= $value ?></td></tr>
        <?php endforeach; ?>
    </table>
    
    <h2>File yang Hilang</h2>
    <?php if (!empty($files_missing)): ?>
    <table>
        <thead><tr><th>Nama File</th><th>Path</th></tr></thead>
        <tbody>
            <?php foreach ($files_missing as $name => $path): ?>
            <tr><td><?= $name ?></td><td><code><?= $path ?></code></td></tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <p class="ok">✅ Semua file lengkap!</p>
    <?php endif; ?>
    
    <h2>Semua Path</h2>
    <table>
        <thead><tr><th>Nama Path</th><th>Path</th><th>Status</th><th>Permission</th></tr></thead>
        <tbody>
            <?php foreach ($paths_to_check as $name => $path): 
                $exists = file_exists($path);
            ?>
            <tr>
                <td><strong><?= $name ?></strong></td>
                <td><code><?= $path ?></code></td>
                <td class="<?= $exists ? 'ok' : 'missing' ?>"><?= $exists ? 'Ada' : 'Tidak Ada' ?></td>
                <td><?= $exists ? substr(sprintf('%o', fileperms($path)), -4) : '-' ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <h2>Developer Folder</h2>
    <table>
        <thead><tr><th>Nama</th><th>Path</th><th>Status</th></tr></thead>
        <tbody>
            <?php foreach ($developer_folders as $name => $path): 
                $exists = file_exists($path);
            ?>
            <tr>
                <td><strong><?= $name ?></strong></td>
                <td><code><?= $path ?></code></td>
                <td class="<?= $exists ? 'ok' : 'missing' ?>"><?= $exists ? 'Ada' : 'Tidak Ada' ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <h2>File Index Developer</h2>
    <table>
        <thead><tr><th>Nama File</th><th>Lokasi</th><th>Status</th></tr></thead>
        <tbody>
            <?php foreach ($developer_files as $name => $path): 
                $exists = file_exists($path);
            ?>
            <tr>
                <td><?= $name ?></td>
                <td><code><?= str_replace($root_path, '', $path) ?></code></td>
                <td class="<?= $exists ? 'ok' : 'missing' ?>"><?= $exists ? 'Ada' : 'Tidak Ada' ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <h2>Isi Folder Logs</h2>
    <?php
    $log_files = [];
    if (is_dir($logs_path)) {
        $log_files = scandir($logs_path);
        $log_files = array_diff($log_files, ['.', '..']);
    }
    ?>
    <p><strong>Lokasi:</strong> <code><?= $logs_path ?></code></p>
    <p><strong>Total File:</strong> <?= count($log_files) ?></p>
    <?php if (!empty($log_files)): ?>
    <table>
        <thead><tr><th>Nama File</th><th>Ukuran</th></tr></thead>
        <tbody>
            <?php foreach ($log_files as $file): 
                $file_path = $logs_path . '/' . $file;
                $size = formatBytes(filesize($file_path));
            ?>
            <tr><td><code><?= $file ?></code></td><td><?= $size ?></td></tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    
    <div class="footer">
        <p>© <?= date('Y') ?> leadproperti.com - Debug Path Checker v3.0</p>
    </div>
</body>
</html>
    <?php
}

// ========== RENDER SESUAI FORMAT ==========
if ($action === 'download' && $format === 'pdf') {
    generatePDF();
} else {
    renderHTML();
}
?>