<?php
header('Location: page1.php');
exit();