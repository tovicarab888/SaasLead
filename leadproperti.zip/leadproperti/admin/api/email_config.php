<?php
/**
 * EMAIL_CONFIG.PHP - Konfigurasi Email untuk SMTP
 * Version: 1.0.0
 * 
 * Letak: /home/taufikma/public_html/admin/api/email_config.php
 */

return [
    'host' => 'mail.leadproperti.com',
    'port' => 465,
    'encryption' => 'ssl',
    'username' => 'info@leadproperti.com',
    'password' => 'Tasya@2323', // PASTIKAN PASSWORD INI BENAR!
    'from_email' => 'info@leadproperti.com',
    'from_name' => 'LeadProperti',
    'timeout' => 30
];
?>