<?php
/**
 * USERS.PHP - Manajemen User untuk Super Admin
 * Version: 5.0.0 - FINAL: Menggunakan Font Awesome Lokal
 */

// Aktifkan session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'api/config.php';

// ========== CHECK AUTH ==========
if (!checkAuth()) {
    header('Location: login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Hanya super admin yang bisa akses
if (!isAdmin()) {
    header('HTTP/1.0 403 Forbidden');
    die('Akses ditolak. Halaman ini hanya untuk Super Admin.');
}

$conn = getDB();
if (!$conn) {
    die("Database connection failed");
}

// ========== PROSES FORM ==========
$success = '';
$error = '';

// Handle Tambah User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $nama_lengkap = trim($_POST['nama_lengkap'] ?? '');
    $role = $_POST['role'] ?? 'developer';
    $developer_id = !empty($_POST['developer_id']) ? (int)$_POST['developer_id'] : null;
    $location_access = trim($_POST['location_access'] ?? '');
    $distribution_mode = $_POST['distribution_mode'] ?? 'FULL_INTERNAL_PLATFORM';
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    // Validasi
    if (empty($username) || empty($email) || empty($password) || empty($nama_lengkap)) {
        $error = "❌ Semua field wajib diisi!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "❌ Format email tidak valid!";
    } else {
        try {
            $conn->beginTransaction();
            
            // Cek username sudah ada
            $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $check->execute([$username, $email]);
            if ($check->fetch()) {
                $error = "❌ Username atau Email sudah digunakan!";
                $conn->rollBack();
            } else {
                // Hash password
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert ke users
                $insert = $conn->prepare("
                    INSERT INTO users (
                        username, email, password, nama_lengkap, role, 
                        developer_id, location_access, distribution_mode, is_active,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                ");
                $insert->execute([
                    $username, $email, $password_hash, $nama_lengkap, $role,
                    $developer_id, $location_access, $distribution_mode, $is_active
                ]);
                
                $user_id = $conn->lastInsertId();
                
                // ===== KHUSUS UNTUK MARKETING EXTERNAL =====
                if ($role === 'marketing_external') {
                    // Cari round_robin_order tertinggi untuk urutan
                    $order_stmt = $conn->query("SELECT MAX(round_robin_order) FROM marketing_external_team");
                    $max_order = $order_stmt->fetchColumn();
                    $new_order = ($max_order === null) ? 0 : $max_order + 1;
                    
                    // Insert ke marketing_external_team
                    $insert_team = $conn->prepare("
                        INSERT INTO marketing_external_team (
                            user_id, 
                            super_admin_id, 
                            round_robin_order, 
                            is_active, 
                            created_at
                        ) VALUES (?, 1, ?, ?, NOW())
                    ");
                    $insert_team->execute([$user_id, $new_order, $is_active]);
                }
                
                $conn->commit();
                $success = "✅ User berhasil ditambahkan!";
            }
        } catch (Exception $e) {
            $conn->rollBack();
            $error = "❌ Gagal menambah user: " . $e->getMessage();
        }
    }
}

// Handle Edit User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = (int)($_POST['id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $nama_lengkap = trim($_POST['nama_lengkap'] ?? '');
    $role = $_POST['role'] ?? 'developer';
    $developer_id = !empty($_POST['developer_id']) ? (int)$_POST['developer_id'] : null;
    $location_access = trim($_POST['location_access'] ?? '');
    $distribution_mode = $_POST['distribution_mode'] ?? 'FULL_INTERNAL_PLATFORM';
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    if ($id > 0 && !empty($username) && !empty($email) && !empty($nama_lengkap)) {
        try {
            $conn->beginTransaction();
            
            // Cek username sudah digunakan user lain
            $check = $conn->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $check->execute([$username, $email, $id]);
            if ($check->fetch()) {
                $error = "❌ Username atau Email sudah digunakan user lain!";
                $conn->rollBack();
            } else {
                // Ambil role lama untuk perbandingan
                $old_role_stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
                $old_role_stmt->execute([$id]);
                $old_role = $old_role_stmt->fetchColumn();
                
                // Update users
                $update = $conn->prepare("
                    UPDATE users SET 
                        username = ?,
                        email = ?,
                        nama_lengkap = ?,
                        role = ?,
                        developer_id = ?,
                        location_access = ?,
                        distribution_mode = ?,
                        is_active = ?,
                        updated_at = NOW()
                    WHERE id = ?
                ");
                $update->execute([
                    $username, $email, $nama_lengkap, $role,
                    $developer_id, $location_access, $distribution_mode, $is_active,
                    $id
                ]);
                
                // Update password jika diisi
                if (!empty($_POST['password'])) {
                    $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $update_pass = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $update_pass->execute([$password_hash, $id]);
                }
                
                // ===== HANDLE PERUBAHAN ROLE UNTUK MARKETING EXTERNAL =====
                
                // Jika role berubah MENJADI marketing_external
                if ($role === 'marketing_external' && $old_role !== 'marketing_external') {
                    // Cek apakah sudah ada di external_team
                    $check_team = $conn->prepare("SELECT id FROM marketing_external_team WHERE user_id = ?");
                    $check_team->execute([$id]);
                    
                    if (!$check_team->fetch()) {
                        // Belum ada, insert baru
                        $order_stmt = $conn->query("SELECT MAX(round_robin_order) FROM marketing_external_team");
                        $max_order = $order_stmt->fetchColumn();
                        $new_order = ($max_order === null) ? 0 : $max_order + 1;
                        
                        $insert_team = $conn->prepare("
                            INSERT INTO marketing_external_team (
                                user_id, super_admin_id, round_robin_order, is_active, created_at
                            ) VALUES (?, 1, ?, ?, NOW())
                        ");
                        $insert_team->execute([$id, $new_order, $is_active]);
                    } else {
                        // Sudah ada, update status
                        $update_team = $conn->prepare("
                            UPDATE marketing_external_team 
                            SET is_active = ?, updated_at = NOW() 
                            WHERE user_id = ?
                        ");
                        $update_team->execute([$is_active, $id]);
                    }
                }
                
                // Jika role berubah DARI marketing_external menjadi role lain
                elseif ($old_role === 'marketing_external' && $role !== 'marketing_external') {
                    // Nonaktifkan di external_team
                    $update_team = $conn->prepare("
                        UPDATE marketing_external_team 
                        SET is_active = 0, updated_at = NOW() 
                        WHERE user_id = ?
                    ");
                    $update_team->execute([$id]);
                }
                
                // Jika role tetap marketing_external, update status
                elseif ($role === 'marketing_external') {
                    $update_team = $conn->prepare("
                        UPDATE marketing_external_team 
                        SET is_active = ?, updated_at = NOW() 
                        WHERE user_id = ?
                    ");
                    $update_team->execute([$is_active, $id]);
                }
                
                $conn->commit();
                $success = "✅ User berhasil diupdate!";
            }
        } catch (Exception $e) {
            $conn->rollBack();
            $error = "❌ Gagal update user: " . $e->getMessage();
        }
    }
}

// Handle Delete (Nonaktifkan User)
if (isset($_GET['delete']) && (int)$_GET['delete'] > 0) {
    $id = (int)$_GET['delete'];
    
    // Cegah nonaktifkan diri sendiri
    if ($id == $_SESSION['user_id']) {
        $error = "❌ Tidak dapat menonaktifkan akun sendiri!";
    } else {
        try {
            $conn->beginTransaction();
            
            // Nonaktifkan di users
            $update = $conn->prepare("UPDATE users SET is_active = 0, deleted_at = NOW() WHERE id = ?");
            $update->execute([$id]);
            
            // Nonaktifkan di marketing_external_team jika ada
            $update_team = $conn->prepare("UPDATE marketing_external_team SET is_active = 0, updated_at = NOW() WHERE user_id = ?");
            $update_team->execute([$id]);
            
            $conn->commit();
            $success = "✅ User berhasil dinonaktifkan!";
        } catch (Exception $e) {
            $conn->rollBack();
            $error = "❌ Gagal menonaktifkan user: " . $e->getMessage();
        }
    }
}

// Handle Aktifkan User
if (isset($_GET['activate']) && (int)$_GET['activate'] > 0) {
    $id = (int)$_GET['activate'];
    
    try {
        $conn->beginTransaction();
        
        $update = $conn->prepare("UPDATE users SET is_active = 1, deleted_at = NULL WHERE id = ?");
        $update->execute([$id]);
        
        // Aktifkan di marketing_external_team jika ada
        $update_team = $conn->prepare("UPDATE marketing_external_team SET is_active = 1, updated_at = NOW() WHERE user_id = ?");
        $update_team->execute([$id]);
        
        $conn->commit();
        $success = "✅ User berhasil diaktifkan!";
    } catch (Exception $e) {
        $conn->rollBack();
        $error = "❌ Gagal mengaktifkan user: " . $e->getMessage();
    }
}

// Handle Delete Permanent User (HANYA UNTUK SUPER ADMIN - DANGER!)
if (isset($_GET['delete_permanent']) && (int)$_GET['delete_permanent'] > 0 && isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    $id = (int)$_GET['delete_permanent'];
    
    // Cegah hapus diri sendiri
    if ($id == $_SESSION['user_id']) {
        $error = "❌ Tidak dapat menghapus akun sendiri!";
    } else {
        try {
            $conn->beginTransaction();
            
            // Hapus dari tabel terkait
            $conn->prepare("DELETE FROM marketing_external_team WHERE user_id = ?")->execute([$id]);
            $conn->prepare("DELETE FROM marketing_team WHERE user_id = ?")->execute([$id]);
            
            // Hapus user
            $conn->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
            
            $conn->commit();
            $success = "✅ User berhasil dihapus permanen!";
        } catch (Exception $e) {
            $conn->rollBack();
            $error = "❌ Gagal menghapus user: " . $e->getMessage();
        }
    }
}

// ========== AMBIL DATA USER ==========
$users = $conn->query("
    SELECT 
        u.*,
        d.nama_lengkap as developer_name
    FROM users u
    LEFT JOIN users d ON u.developer_id = d.id
    ORDER BY 
        CASE 
            WHEN u.role = 'admin' THEN 1
            WHEN u.role = 'manager' THEN 2
            WHEN u.role = 'finance_platform' THEN 3
            WHEN u.role = 'developer' THEN 4
            WHEN u.role = 'manager_developer' THEN 5
            WHEN u.role = 'finance' THEN 6
            WHEN u.role = 'marketing_external' THEN 7
            ELSE 8
        END,
        u.nama_lengkap ASC
")->fetchAll();

// ========== AMBIL DATA DEVELOPER UNTUK DROPDOWN ==========
$developers = $conn->query("
    SELECT id, nama_lengkap, nama_perusahaan 
    FROM users 
    WHERE role = 'developer' AND is_active = 1
    ORDER BY nama_lengkap
")->fetchAll();

// ========== AMBIL DATA LOKASI UNTUK DROPDOWN ==========
$locations = $conn->query("SELECT location_key, display_name FROM locations ORDER BY sort_order")->fetchAll();

// ========== SET VARIABLES ==========
$page_title = 'Manajemen User';
$page_subtitle = 'Kelola Semua User dan Hak Akses';
$page_icon = 'fas fa-users-cog';

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
/* ===== MOBILE FIRST VARIABLES ===== */
:root {
    --primary: #1B4A3C;
    --primary-light: #2A5F4E;
    --secondary: #D64F3C;
    --secondary-light: #FF6B4A;
    --bg: #F5F3F0;
    --surface: #FFFFFF;
    --text: #1A2A24;
    --text-light: #4A5A54;
    --text-muted: #7A8A84;
    --border: #E0DAD3;
    --primary-soft: #E7F3EF;
    --success: #2A9D8F;
    --warning: #E9C46A;
    --danger: #D64F3C;
    --info: #4A90E2;
}

/* ===== MOBILE FIRST LAYOUT ===== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.5;
    -webkit-font-smoothing: antialiased;
}

.main-content {
    width: 100%;
    min-height: 100vh;
    padding: 12px;
    margin-left: 0 !important;
}

/* ===== TOP BAR - MOBILE FIRST ===== */
.top-bar {
    background: var(--surface);
    border-radius: 20px;
    padding: 16px;
    margin-bottom: 16px;
    border-left: 6px solid var(--secondary);
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.welcome-text {
    display: flex;
    align-items: center;
    gap: 12px;
}

.welcome-text i {
    width: 48px;
    height: 48px;
    flex-shrink: 0;
    background: rgba(214,79,60,0.1);
    color: var(--secondary);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.welcome-text h2 {
    font-size: 18px;
    font-weight: 800;
    color: var(--text);
    line-height: 1.3;
}

.welcome-text h2 span {
    display: block;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-muted);
    margin-top: 2px;
}

.datetime {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: var(--bg);
    padding: 8px 16px;
    border-radius: 40px;
    font-size: 13px;
    font-weight: 600;
    color: var(--primary);
}

.time {
    background: var(--surface);
    padding: 4px 12px;
    border-radius: 30px;
}

/* ===== ALERT ===== */
.alert {
    padding: 14px 16px;
    border-radius: 16px;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 13px;
    border-left: 4px solid;
}

.alert.success {
    background: #d4edda;
    color: #155724;
    border-left-color: #28a745;
}

.alert.error {
    background: #f8d7da;
    color: #721c24;
    border-left-color: var(--danger);
}

/* ===== ACTION BAR ===== */
.action-bar {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 20px;
}

.btn-add {
    width: 100%;
    background: linear-gradient(135deg, var(--secondary), var(--secondary-light));
    color: white;
    border: none;
    padding: 16px;
    border-radius: 50px;
    font-weight: 700;
    font-size: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    box-shadow: 0 8px 20px rgba(214,79,60,0.2);
    transition: all 0.3s;
    min-height: 56px;
    text-decoration: none;
}

.btn-add i {
    font-size: 16px;
    width: auto;
    height: auto;
}

.btn-add:active {
    transform: scale(0.98);
}

/* ===== TABLE CARD ===== */
.table-card {
    background: white;
    border-radius: 24px;
    padding: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.05);
    border: 1px solid var(--border);
    margin-bottom: 24px;
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 2px solid var(--primary-soft);
    flex-wrap: wrap;
    gap: 10px;
}

.table-header h3 {
    font-size: 16px;
    font-weight: 700;
    color: var(--primary);
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
}

.table-header h3 i {
    color: var(--secondary);
}

.table-badge {
    background: var(--primary-soft);
    color: var(--primary);
    padding: 6px 14px;
    border-radius: 30px;
    font-size: 12px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.table-responsive {
    overflow-x: auto;
    margin: 0 -16px;
    padding: 0 16px;
    width: calc(100% + 32px);
    -webkit-overflow-scrolling: touch;
    border-radius: 0 0 16px 16px;
}

.table-responsive::-webkit-scrollbar {
    height: 4px;
}

.table-responsive::-webkit-scrollbar-track {
    background: var(--primary-soft);
    border-radius: 10px;
}

.table-responsive::-webkit-scrollbar-thumb {
    background: var(--secondary);
    border-radius: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1200px;
}

th {
    background: linear-gradient(135deg, var(--primary-soft), #d4e8e0);
    padding: 16px 12px;
    text-align: left;
    font-weight: 700;
    color: var(--primary);
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
}

td {
    padding: 16px 12px;
    border-bottom: 1px solid var(--border);
    vertical-align: middle;
    font-size: 13px;
}

tr:hover td {
    background: var(--primary-soft);
}

/* ===== ROLE BADGE ===== */
.role-badge {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 30px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
    text-align: center;
    color: white;
    min-width: 110px;
}

.role-badge.admin {
    background: #D64F3C;
}

.role-badge.manager {
    background: #1B4A3C;
}

.role-badge.finance_platform {
    background: #2A9D8F;
}

.role-badge.developer {
    background: #E3B584;
    color: #1A2A24;
}

.role-badge.manager_developer {
    background: #4A90E2;
}

.role-badge.finance {
    background: #9B59B6;
}

.role-badge.marketing_external {
    background: #D64F3C;
    opacity: 0.9;
}

/* ===== STATUS BADGE ===== */
.status-badge {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 30px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
    text-align: center;
    color: white;
    min-width: 70px;
}

.status-badge.active {
    background: var(--success);
}

.status-badge.inactive {
    background: var(--danger);
}

/* ===== ACTION BUTTONS HORIZONTAL ===== */
.action-buttons {
    display: flex;
    gap: 6px;
    justify-content: center;
    align-items: center;
    flex-direction: row;
    flex-wrap: nowrap;
}

.action-btn {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
    border: 1px solid;
    background: white;
    flex-shrink: 0;
}

.action-btn.edit {
    background: #fff8e1;
    color: #ff8f00;
    border-color: #ff8f00;
}

.action-btn.edit:hover {
    background: #ff8f00;
    color: white;
}

.action-btn.delete {
    background: #ffebee;
    color: #d32f2f;
    border-color: #d32f2f;
}

.action-btn.delete:hover {
    background: #d32f2f;
    color: white;
}

.action-btn.activate {
    background: #e8f5e9;
    color: #2e7d32;
    border-color: #2e7d32;
}

.action-btn.activate:hover {
    background: #2e7d32;
    color: white;
}

.action-btn[style*="opacity"] {
    pointer-events: none;
    opacity: 0.4 !important;
}

/* ===== MODAL ===== */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
    z-index: 10000;
    align-items: flex-end;
    justify-content: center;
    padding: 0;
}

.modal.show {
    display: flex !important;
}

.modal-content {
    background: white;
    border-radius: 28px 28px 0 0;
    width: 100%;
    max-height: 90vh;
    display: flex;
    flex-direction: column;
    animation: slideUp 0.3s ease;
}

@keyframes slideUp {
    from { transform: translateY(100%); }
    to { transform: translateY(0); }
}

.modal-header {
    padding: 20px 20px 16px;
    border-bottom: 2px solid var(--primary-soft);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    color: var(--primary);
    font-size: 18px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 8px;
}

.modal-header h2 i {
    color: var(--secondary);
    font-size: 20px;
}

.modal-close {
    width: 44px;
    height: 44px;
    background: var(--primary-soft);
    border: none;
    border-radius: 12px;
    color: var(--secondary);
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-body {
    padding: 20px;
    overflow-y: auto;
    max-height: 60vh;
}

.modal-footer {
    padding: 16px 20px 24px;
    display: flex;
    gap: 12px;
    border-top: 1px solid var(--border);
}

.modal-footer button {
    flex: 1;
    min-height: 48px;
    border-radius: 40px;
    font-weight: 600;
    font-size: 15px;
}

@media (min-width: 768px) {
    .modal {
        align-items: center;
        padding: 20px;
    }
    
    .modal-content {
        border-radius: 28px;
        max-width: 600px;
        animation: modalFade 0.3s ease;
    }
    
    @keyframes modalFade {
        from { opacity: 0; transform: scale(0.9); }
        to { opacity: 1; transform: scale(1); }
    }
}

/* ===== FORM ELEMENTS ===== */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--primary);
    font-size: 14px;
}

.form-group label i {
    color: var(--secondary);
    margin-right: 6px;
}

.form-control, .form-select {
    width: 100%;
    padding: 14px 16px;
    border: 2px solid var(--border);
    border-radius: 14px;
    font-size: 16px;
    font-family: 'Inter', sans-serif;
    background: white;
    min-height: 52px;
}

.form-control:focus, .form-select:focus {
    border-color: var(--secondary);
    outline: none;
}

.checkbox-group {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: var(--primary-soft);
    border-radius: 14px;
    margin-bottom: 20px;
}

.checkbox-group input[type="checkbox"] {
    width: 22px;
    height: 22px;
    accent-color: var(--secondary);
}

.checkbox-group label {
    margin: 0;
    font-weight: 600;
    color: var(--primary);
    cursor: pointer;
}

/* ===== BUTTONS ===== */
.btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--primary-light));
    color: white;
    border: none;
    padding: 14px 20px;
    border-radius: 40px;
    font-weight: 700;
    font-size: 15px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 52px;
}

.btn-secondary {
    background: var(--border);
    color: var(--text);
    border: none;
    padding: 14px 20px;
    border-radius: 40px;
    font-weight: 600;
    font-size: 15px;
    cursor: pointer;
    min-height: 52px;
}

/* ===== EMPTY STATE ===== */
.empty-state {
    text-align: center;
    padding: 40px 20px;
    background: white;
    border-radius: 16px;
}

.empty-state i {
    font-size: 48px;
    color: #E0DAD3;
    margin-bottom: 16px;
}

.empty-state p {
    color: var(--text-muted);
}

/* ===== FOOTER ===== */
.footer {
    text-align: center;
    margin-top: 30px;
    padding: 20px;
    color: var(--text-muted);
    font-size: 12px;
    border-top: 1px solid var(--border);
}

/* ===== TABLET & DESKTOP UPGRADE ===== */
@media (min-width: 768px) {
    .main-content {
        margin-left: 280px !important;
        padding: 24px !important;
    }
    
    .top-bar {
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding: 20px 24px;
    }
    
    .welcome-text i {
        width: 56px;
        height: 56px;
        font-size: 24px;
    }
    
    .welcome-text h2 {
        font-size: 22px;
    }
    
    .action-bar {
        flex-direction: row;
        justify-content: flex-start;
    }
    
    .btn-add {
        width: auto;
        padding: 14px 28px;
    }
    
    .table-card {
        padding: 24px;
    }
    
    .table-responsive {
        margin: 0 -24px;
        padding: 0 24px;
        width: calc(100% + 48px);
    }
}
</style>

<div class="main-content">
    
    <!-- TOP BAR -->
    <div class="top-bar">
        <div class="welcome-text">
            <i class="<?= $page_icon ?>"></i>
            <h2>
                <?= $page_title ?>
                <span><?= $page_subtitle ?></span>
            </h2>
        </div>
        <div class="datetime">
            <div class="date"><i class="fas fa-calendar-alt"></i> <span></span></div>
            <div class="time"><i class="fas fa-clock"></i> <span></span></div>
        </div>
    </div>
    
    <!-- ALERT MESSAGES -->
    <?php if ($success): ?>
    <div class="alert success">
        <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="alert error">
        <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <!-- ACTION BUTTON -->
    <div class="action-bar">
        <button onclick="openAddModal()" class="btn-add">
            <i class="fas fa-plus-circle"></i> Tambah User Baru
        </button>
    </div>
    
    <!-- TABLE USERS -->
    <div class="table-card">
        <div class="table-header">
            <h3><i class="fas fa-users"></i> Daftar User</h3>
            <div class="table-badge">
                <i class="fas fa-database"></i> Total: <?= count($users) ?> user
            </div>
        </div>
        
        <?php if (empty($users)): ?>
        <div class="empty-state">
            <i class="fas fa-users"></i>
            <p>Belum ada user</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Developer</th>
                        <th>Akses Lokasi</th>
                        <th>Mode</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td><strong>#<?= $u['id'] ?></strong></td>
                        <td><strong style="color: var(--primary);"><?= htmlspecialchars($u['nama_lengkap']) ?></strong></td>
                        <td><?= htmlspecialchars($u['username']) ?></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td>
                            <span class="role-badge <?= $u['role'] ?>">
                                <?php 
                                $role_display = strtoupper(str_replace('_', ' ', $u['role']));
                                if ($u['role'] === 'marketing_external') {
                                    $role_display = 'MARKETING EXTERNAL';
                                }
                                echo $role_display;
                                ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($u['developer_id']): ?>
                                <?= htmlspecialchars($u['developer_name'] ?? 'ID: ' . $u['developer_id']) ?>
                            <?php else: ?>
                                <span style="color: var(--text-muted);">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($u['location_access']): ?>
                                <?= htmlspecialchars($u['location_access']) ?>
                            <?php else: ?>
                                <span style="color: var(--text-muted);">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($u['distribution_mode']): ?>
                                <span style="background: var(--primary-soft); padding: 4px 8px; border-radius: 20px; font-size: 10px; white-space: nowrap;">
                                    <?= $u['distribution_mode'] ?>
                                </span>
                            <?php else: ?>
                                <span style="color: var(--text-muted);">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="status-badge <?= $u['is_active'] ? 'active' : 'inactive' ?>">
                                <?= $u['is_active'] ? 'Aktif' : 'Nonaktif' ?>
                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <!-- EDIT BUTTON -->
                                <button class="action-btn edit" onclick='editUser(<?= json_encode($u) ?>)' title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                
                                <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                    <?php if ($u['is_active']): ?>
                                        <!-- NONAKTIFKAN BUTTON -->
                                        <a href="?delete=<?= $u['id'] ?>" class="action-btn delete" 
                                           onclick="return confirm('Nonaktifkan user <?= htmlspecialchars($u['nama_lengkap']) ?>?')" 
                                           title="Nonaktifkan">
                                            <i class="fas fa-ban"></i>
                                        </a>
                                    <?php else: ?>
                                        <!-- AKTIFKAN BUTTON -->
                                        <a href="?activate=<?= $u['id'] ?>" class="action-btn activate" 
                                           onclick="return confirm('Aktifkan user <?= htmlspecialchars($u['nama_lengkap']) ?>?')" 
                                           title="Aktifkan">
                                            <i class="fas fa-check-circle"></i>
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <!-- Untuk diri sendiri -->
                                    <span class="action-btn" style="opacity: 0.3; cursor: not-allowed; border-color: #ccc;" title="Tidak bisa mengubah status akun sendiri">
                                        <i class="fas fa-ban"></i>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- FOOTER -->
    <div class="footer">
        <p>© <?= date('Y') ?> LeadEngine - Users Management v5.0.0</p>
    </div>
    
</div>

<!-- MODAL ADD USER -->
<div class="modal" id="addModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h2><i class="fas fa-plus-circle"></i> Tambah User</h2>
            <button class="modal-close" onclick="closeModal('addModal')">&times;</button>
        </div>
        
        <form method="POST">
            <input type="hidden" name="action" value="add">
            
            <div class="modal-body">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-user-circle"></i> Username *</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email *</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password *</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Role *</label>
                    <select name="role" id="add_role" class="form-control" required onchange="toggleRoleFields('add')">
                        <option value="">Pilih Role</option>
                        <option value="admin">Super Admin</option>
                        <option value="manager">Manager Platform</option>
                        <option value="finance_platform">Finance Platform</option>
                        <option value="developer">Developer</option>
                        <option value="manager_developer">Manager Developer</option>
                        <option value="finance">Finance Developer</option>
                        <option value="marketing_external">Marketing External</option>
                    </select>
                </div>
                
                <div id="add_developer_fields" style="display: none;">
                    <div class="form-group">
                        <label><i class="fas fa-building"></i> Developer</label>
                        <select name="developer_id" class="form-control">
                            <option value="">Pilih Developer</option>
                            <?php foreach ($developers as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nama_lengkap']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div id="add_developer_access" style="display: none;">
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Akses Lokasi</label>
                        <select name="location_access" class="form-control">
                            <option value="">Semua Lokasi</option>
                            <?php foreach ($locations as $loc): ?>
                            <option value="<?= $loc['location_key'] ?>"><?= $loc['display_name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-chart-pie"></i> Distribution Mode</label>
                        <select name="distribution_mode" class="form-control">
                            <option value="FULL_INTERNAL_PLATFORM">FULL INTERNAL</option>
                            <option value="SPLIT_50_50">SPLIT 50:50</option>
                        </select>
                    </div>
                </div>
                
                <div class="checkbox-group">
                    <input type="checkbox" name="is_active" id="add_active" value="1" checked>
                    <label for="add_active">Aktif</label>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('addModal')">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL EDIT USER -->
<div class="modal" id="editModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h2><i class="fas fa-edit"></i> Edit User</h2>
            <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
        </div>
        
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="edit_id" value="">
            
            <div class="modal-body">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Nama Lengkap</label>
                    <input type="text" name="nama_lengkap" id="edit_nama" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-user-circle"></i> Username</label>
                    <input type="text" name="username" id="edit_username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" name="email" id="edit_email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password (kosongkan jika tidak diubah)</label>
                    <input type="password" name="password" class="form-control">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Role</label>
                    <select name="role" id="edit_role" class="form-control" required onchange="toggleRoleFields('edit')">
                        <option value="admin">Super Admin</option>
                        <option value="manager">Manager Platform</option>
                        <option value="finance_platform">Finance Platform</option>
                        <option value="developer">Developer</option>
                        <option value="manager_developer">Manager Developer</option>
                        <option value="finance">Finance Developer</option>
                        <option value="marketing_external">Marketing External</option>
                    </select>
                </div>
                
                <div id="edit_developer_fields" style="display: none;">
                    <div class="form-group">
                        <label><i class="fas fa-building"></i> Developer</label>
                        <select name="developer_id" id="edit_developer_id" class="form-control">
                            <option value="">Pilih Developer</option>
                            <?php foreach ($developers as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nama_lengkap']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div id="edit_developer_access" style="display: none;">
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Akses Lokasi</label>
                        <select name="location_access" id="edit_location_access" class="form-control">
                            <option value="">Semua Lokasi</option>
                            <?php foreach ($locations as $loc): ?>
                            <option value="<?= $loc['location_key'] ?>"><?= $loc['display_name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-chart-pie"></i> Distribution Mode</label>
                        <select name="distribution_mode" id="edit_distribution_mode" class="form-control">
                            <option value="FULL_INTERNAL_PLATFORM">FULL INTERNAL</option>
                            <option value="SPLIT_50_50">SPLIT 50:50</option>
                        </select>
                    </div>
                </div>
                
                <div class="checkbox-group">
                    <input type="checkbox" name="is_active" id="edit_active" value="1">
                    <label for="edit_active">Aktif</label>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('editModal')">Batal</button>
                <button type="submit" class="btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleRoleFields(prefix) {
    const role = document.getElementById(prefix + '_role').value;
    const devFields = document.getElementById(prefix + '_developer_fields');
    const devAccess = document.getElementById(prefix + '_developer_access');
    
    devFields.style.display = 'none';
    devAccess.style.display = 'none';
    
    if (role === 'manager_developer' || role === 'finance') {
        devFields.style.display = 'block';
    }
    
    if (role === 'developer') {
        devFields.style.display = 'block';
        devAccess.style.display = 'block';
    }
}

function openAddModal() {
    document.getElementById('add_role').value = '';
    document.getElementById('add_developer_fields').style.display = 'none';
    document.getElementById('add_developer_access').style.display = 'none';
    document.getElementById('add_active').checked = true;
    openModal('addModal');
}

function editUser(user) {
    document.getElementById('edit_id').value = user.id;
    document.getElementById('edit_nama').value = user.nama_lengkap;
    document.getElementById('edit_username').value = user.username;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_role').value = user.role;
    document.getElementById('edit_developer_id').value = user.developer_id || '';
    document.getElementById('edit_location_access').value = user.location_access || '';
    document.getElementById('edit_distribution_mode').value = user.distribution_mode || 'FULL_INTERNAL_PLATFORM';
    document.getElementById('edit_active').checked = user.is_active == 1;
    toggleRoleFields('edit');
    openModal('editModal');
}

function openModal(id) {
    document.getElementById(id).classList.add('show');
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
    document.body.style.overflow = '';
}

function updateDateTime() {
    const now = new Date();
    document.querySelector('.date span').textContent = now.toLocaleDateString('id-ID', { 
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
    });
    document.querySelector('.time span').textContent = now.toLocaleTimeString('id-ID', { 
        hour12: false 
    });
}
setInterval(updateDateTime, 1000);
updateDateTime();

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
        document.body.style.overflow = '';
    }
});

window.openAddModal = openAddModal;
window.closeModal = closeModal;
window.editUser = editUser;
window.toggleRoleFields = toggleRoleFields;
</script>

<?php include 'includes/footer.php'; ?>